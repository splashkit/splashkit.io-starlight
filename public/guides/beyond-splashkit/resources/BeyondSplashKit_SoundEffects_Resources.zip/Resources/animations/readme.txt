You can place scripts for animations in this folder.

See the "Using Animations" guide on this page https://splashkit.io/guides/ for more information.
