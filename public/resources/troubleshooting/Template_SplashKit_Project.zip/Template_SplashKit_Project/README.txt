To use this template SplashKit project folder:

1. Create a new folder for your new task in your 'Code' folder, or similar (not in this folder).

2. Copy this folder's contents and paste them into your newly create folder.

3. Open the 'Program.cs' file and update the line starting with 'namespace ' using the name of 
your new folder (without any spaces, and starting with an Uppercase letter).
eg. For task 1.1P, you would have 'namespace HelloWorld' on that line instead.

4. Update your project file's filename (the .csproj file) to be the same as the name you used 
for the namespace in step 3.

5. To test that it is working, you can copy the following code lines into Main:

Window window = new Window("Testing", 800, 600);
window.Clear(Color.White);
window.FillCircle(Color.Blue, 400, 300, 100);
window.Refresh(60);
SplashKit.Delay(2000);
