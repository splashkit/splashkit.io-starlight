using System;
using SplashKitSDK;

// Update the namespace below to your new folder/project name
// And update the "Template_SplashKit_Project.csproj" file to use your new folder/project name
// Then you can remove these comment lines
namespace Template_SplashKit_Project
{
    public class Program
    {
        public static void Main()
        {

        }
    }
}
